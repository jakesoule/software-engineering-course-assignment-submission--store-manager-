Jake Soule
101131271
A3 - COMP2404

Control.o: Launches the program and controls each class

List.o: Linked list class to contain Locations

Location.o: Parent class to StoreLocation and WHLocation - contains base information about the two and provides virtual functions

Product.o: Contains information and functions about products

Queue.o: Linked queue class to contain WHLocations

Store.o: Contains functions and data to manage store and store inventory

StoreLocation.o: Contains data and functions for each specific store

View.o: User interface for program

WHLocation.o: Contains data and functions for each specific warehouse

------------------------------

To compile: open terminal here (in folder where README is located), then:

"make -f Makefile"


To run executable a3: open terminal here (in folder where README is located), then:

"./a3"